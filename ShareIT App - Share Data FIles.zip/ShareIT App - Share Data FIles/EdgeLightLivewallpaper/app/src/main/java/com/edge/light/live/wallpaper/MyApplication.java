package com.edge.light.live.wallpaper;

import android.app.Application;

public class MyApplication extends Application {
    private static  com.edge.light.live.wallpaper.MyApplication mInstance;

    @Override
    public void onCreate() {
        super.onCreate();

        mInstance = this;
    }

    public static  com.edge.light.live.wallpaper.MyApplication getInstance() {
        return mInstance;
    }

}
