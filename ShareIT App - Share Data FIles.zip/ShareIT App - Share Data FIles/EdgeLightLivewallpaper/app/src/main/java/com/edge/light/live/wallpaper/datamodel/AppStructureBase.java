package com.edge.light.live.wallpaper.datamodel;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class AppStructureBase {


    @SerializedName("inter_id")
    private String inter_id;
    @SerializedName("banner_id")
    private String banner_id;
    @SerializedName("native_id")
    private String native_id;


    @SerializedName("fb_banner_id")
    private String fb_banner_id;

    @SerializedName("fb_inter_id")
    private String fb_inter_id;

    @SerializedName("fb_native_id")
    private String fb_native_id;

    @SerializedName("fb_banner_home")
    private int fb_banner_home;
    @SerializedName("google_banner_home")
    private int google_banner_home;

    @SerializedName("google_native_option1")
    private int google_native_option1;
    @SerializedName("fb_native_option1")
    private int fb_native_option1;

    @SerializedName("google_banner_option2")
    private int google_banner_option2;
    @SerializedName("fb_banner_option2")
    private int fb_banner_option2;

    @SerializedName("fb_inter_home")
    private int fb_inter_home;
    @SerializedName("google_inter_home")
    private int google_inter_home;

    @SerializedName("google_inter_option1")
    private int google_inter_option1;
    @SerializedName("fb_inter_option1")
    private int fb_inter_option1;

    @SerializedName("google_inter_option2")
    private int google_inter_option2;
    @SerializedName("fb_inter_option2")
    private int fb_inter_option2;

    public String getInter_id() {
        return inter_id;
    }

    public void setInter_id(String inter_id) {
        this.inter_id = inter_id;
    }

    public String getBanner_id() {
        return banner_id;
    }

    public void setBanner_id(String banner_id) {
        this.banner_id = banner_id;
    }

    public String getNative_id() {
        return native_id;
    }

    public void setNative_id(String native_id) {
        this.native_id = native_id;
    }

    public String getFb_banner_id() {
        return fb_banner_id;
    }

    public void setFb_banner_id(String fb_banner_id) {
        this.fb_banner_id = fb_banner_id;
    }

    public String getFb_inter_id() {
        return fb_inter_id;
    }

    public void setFb_inter_id(String fb_inter_id) {
        this.fb_inter_id = fb_inter_id;
    }

    public String getFb_native_id() {
        return fb_native_id;
    }

    public void setFb_native_id(String fb_native_id) {
        this.fb_native_id = fb_native_id;
    }

    public int getFb_banner_home() {
        return fb_banner_home;
    }

    public void setFb_banner_home(int fb_banner_home) {
        this.fb_banner_home = fb_banner_home;
    }

    public int getGoogle_banner_home() {
        return google_banner_home;
    }

    public void setGoogle_banner_home(int google_banner_home) {
        this.google_banner_home = google_banner_home;
    }

    public int getGoogle_native_option1() {
        return google_native_option1;
    }

    public void setGoogle_native_option1(int google_native_option1) {
        this.google_native_option1 = google_native_option1;
    }

    public int getFb_native_option1() {
        return fb_native_option1;
    }

    public void setFb_native_option1(int fb_native_option1) {
        this.fb_native_option1 = fb_native_option1;
    }

    public int getGoogle_banner_option2() {
        return google_banner_option2;
    }

    public void setGoogle_banner_option2(int google_banner_option2) {
        this.google_banner_option2 = google_banner_option2;
    }

    public int getFb_banner_option2() {
        return fb_banner_option2;
    }

    public void setFb_banner_option2(int fb_banner_option2) {
        this.fb_banner_option2 = fb_banner_option2;
    }

    public int getFb_inter_home() {
        return fb_inter_home;
    }

    public void setFb_inter_home(int fb_inter_home) {
        this.fb_inter_home = fb_inter_home;
    }

    public int getGoogle_inter_home() {
        return google_inter_home;
    }

    public void setGoogle_inter_home(int google_inter_home) {
        this.google_inter_home = google_inter_home;
    }

    public int getGoogle_inter_option1() {
        return google_inter_option1;
    }

    public void setGoogle_inter_option1(int google_inter_option1) {
        this.google_inter_option1 = google_inter_option1;
    }

    public int getFb_inter_option1() {
        return fb_inter_option1;
    }

    public void setFb_inter_option1(int fb_inter_option1) {
        this.fb_inter_option1 = fb_inter_option1;
    }

    public int getGoogle_inter_option2() {
        return google_inter_option2;
    }

    public void setGoogle_inter_option2(int google_inter_option2) {
        this.google_inter_option2 = google_inter_option2;
    }

    public int getFb_inter_option2() {
        return fb_inter_option2;
    }

    public void setFb_inter_option2(int fb_inter_option2) {
        this.fb_inter_option2 = fb_inter_option2;
    }
}
