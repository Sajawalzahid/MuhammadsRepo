package com.edge.light.live.wallpaper.service;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.SweepGradient;
import android.os.Build;
import android.os.Handler;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.view.animation.OvershootInterpolator;
import com.edge.light.live.wallpaper.R;
import java.io.File;

public class CornerWallpaperService extends WallpaperService {

    private class MyEngine extends Engine {
        boolean aBoolean;
        float animation_speed;

        /* renamed from: b1 */
        boolean f76b1;
        Bitmap bitmap;
        int blur;
        float border_size;

        /* renamed from: bz */
        float f77bz;
        int color1;
        int color2;
        int color3;
        int color4;
        ColorMatrix colorMatrix;
        ColorMatrix colorMatrix1;
        ColorMatrixColorFilter colorMatrixColorFilter;
        CornerWallpaperService cornerWallpaperService;
        long f23i = 0;
        Runnable f24r;
        Handler handler = new Handler();
        int height;

        /* renamed from: i1 */
        long f78i1 = 0;
        boolean isTrue;
        Canvas lockHardwareCanvas;
        boolean mBoolean;
        Paint paint;
        Paint paint1;
        Paint paint2;
        Path path;
        Path path1;
        float power;
        SharedPreferences preferences;
        Runnable runnable;
        SharedPreferences.OnSharedPreferenceChangeListener sharedPreferenceChangeListener;
        SurfaceHolder surfaceHolder;
        SweepGradient sweepGradient;
        int thiknesssize;


        int f79w;
        int width;

        class changelistener implements SharedPreferences.OnSharedPreferenceChangeListener {
            final MyEngine engine;

            changelistener(MyEngine myEngine) {
                this.engine = myEngine;
            }

            public final void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String str) {
                if (str.equals("enablenotch") || str.equals("curvetop") || str.equals("curvebottom") || str.equals("notchwidth") || str.equals("notchheight") || str.equals("notchradiustop") || str.equals("notchradiusbottom") || str.equals("notchfullnessbottom")) {
                    synchronized (this) {
                        MyEngine.this.drawRectPlain();
                    }
                } else if (str.equals("newimage") && MyEngine.this.preferences.getBoolean("newimage", false)) {
                    MyEngine.this.preferences.edit().putBoolean("newimage", false).apply();
                    MyEngine.this.handler.removeCallbacks(MyEngine.this.f24r);
                    MyEngine.this.handler.post(MyEngine.this.f24r);
                } else if (str.equals("thiknesssize")) {
                    MyEngine.this.f77bz = (float) sharedPreferences.getInt("thiknesssize", MyEngine.this.thiknesssize);
                } else if (str.equals("bordersizelockscreen")) {
                    MyEngine.this.border_size = (float) sharedPreferences.getInt("bordersizelockscreen", 20);
                } else if (str.equals("animationspeed")) {
                    MyEngine.this.animation_speed = (float) sharedPreferences.getInt("animationspeed", 20);
                } else if (str.equals("color.1")) {
                    MyEngine.this.color1 = sharedPreferences.getInt("color.1", Color.argb(255, 236, 243, 27));
                    MyEngine.this.border_shade();
                } else if (str.equals("color.2")) {
                    MyEngine.this.color2 = sharedPreferences.getInt("color.2", Color.argb(255, 42, 146, 65));
                    MyEngine.this.border_shade();
                } else if (str.equals("color.3")) {
                    MyEngine.this.color3 = sharedPreferences.getInt("color.3", Color.argb(255, 180, 6, 183));
                    MyEngine.this.border_shade();
                } else if (str.equals("color.4")) {
                    MyEngine.this.color4 = sharedPreferences.getInt("color.4", Color.argb(255, 38, 36, 122));
                    MyEngine.this.border_shade();
                }
            }
        }

        public final void onCreate(SurfaceHolder surfaceHolder2) {
            super.onCreate(surfaceHolder2);
            this.f79w = CornerWallpaperService.this.getResources().getDisplayMetrics().widthPixels;
            this.thiknesssize = (this.f79w * 20) / 1080;
            this.surfaceHolder = surfaceHolder2;
            this.preferences = this.cornerWallpaperService.getSharedPreferences(MYHelper.share_pref_key, 0);
            this.sharedPreferenceChangeListener = new changelistener(this);
            this.preferences.registerOnSharedPreferenceChangeListener(this.sharedPreferenceChangeListener);
            this.f77bz = (float) this.preferences.getInt("thiknesssize", this.thiknesssize);
            this.border_size = (float) this.preferences.getInt("thiknesssizelockscreen", 20);
            this.animation_speed = (float) this.preferences.getInt("animationspeed", 20);
            this.color1 = this.preferences.getInt("color.1", Color.argb(255, 236, 243, 27));
            this.color2 = this.preferences.getInt("color.2", Color.argb(255, 42, 146, 65));
            this.color3 = this.preferences.getInt("color.3", Color.argb(255, 180, 6, 183));
            this.color4 = this.preferences.getInt("color.4", Color.argb(255, 38, 36, 122));
            this.blur = this.preferences.getInt("blur", 0);
        }

        public MyEngine(CornerWallpaperService cornerWallpaperService2) {
            super();
            this.cornerWallpaperService = cornerWallpaperService2;
            this.runnable = new Runnable() {
                public void run() {
                    MyEngine.this.onDraw();
                }
            };
            this.f24r = new Runnable() {
                public void run() {
                    MyEngine.this.setbgImg();
                }
            };
        }


        public void border_shade() {
            this.sweepGradient = new SweepGradient((float) (this.height / 2), (float) (this.width / 2), new int[]{this.color1, this.color2, this.color3, this.color4}, (float[]) null);
            this.paint.setShader(this.sweepGradient);
        }

        public void onDraw() {
            int i = Build.VERSION.SDK_INT;
            if (this.isTrue) {
                keygauard();
                this.lockHardwareCanvas = this.surfaceHolder.lockCanvas();
                if (this.aBoolean) {
                    Matrix matrix = new Matrix();
                    matrix.preRotate(-90.0f);
                    matrix.postTranslate(0.0f, (float) this.height);
                    this.lockHardwareCanvas.setMatrix(matrix);
                }
                int nanoTime = (int) ((System.nanoTime() - (this.f23i + 300000000)) / 1000000);
                int i2 = Math.max(Math.min(nanoTime, 1000), 0);
                float f = this.border_size;
                float interpolation = new OvershootInterpolator().getInterpolation(((float) i2) / 1000.0f) * (((this.f77bz - f) * time()) + f);
                this.lockHardwareCanvas.drawColor(0, PorterDuff.Mode.CLEAR);
                if (this.bitmap != null && this.preferences.getBoolean("enableimage", false)) {
                    float width2 = (float) ((this.height - this.bitmap.getWidth()) / 2);
                    float f2 = (float) ((this.width - this.bitmap.getHeight()) / 2);
                    this.colorMatrix.postConcat(new ColorMatrix(this.colorMatrix1));
                    this.paint1.setColorFilter(new ColorMatrixColorFilter(this.colorMatrix));
                    this.lockHardwareCanvas.drawBitmap(this.bitmap, width2, f2, this.paint1);
                }
                double d = (double) nanoTime;
                double pow = Math.pow((double) (21.0f - this.animation_speed), 1.3d);
                Double.isNaN(d);
                this.power = (float) (d / pow);
                Matrix matrix2 = new Matrix();
                matrix2.preRotate(this.power, (float) (this.height / 2), (float) (this.width / 2));
                this.sweepGradient.setLocalMatrix(matrix2);
                this.paint.setStrokeWidth(interpolation);
                if (interpolation > 0.001f) {
                    this.lockHardwareCanvas.drawPath(this.path, this.paint);
                }
                this.lockHardwareCanvas.drawPath(this.path1, this.paint2);
                if (this.lockHardwareCanvas != null) {
                    this.surfaceHolder.getSurface().unlockCanvasAndPost(this.lockHardwareCanvas);
                }
                this.handler.post(this.runnable);
            }
        }


        public void drawRectPlain() {
            int w = CornerWallpaperService.this.getResources().getDisplayMetrics().widthPixels;
            float f = (float) this.preferences.getInt("curvetop", (w * 60) / 1080);
            float f2 = (float) this.preferences.getInt("curvebottom", (w * 60) / 1080);
            float f3 = (float) this.preferences.getInt("notchheight", (w * 75) / 1080);
            float f4 = (float) (this.preferences.getInt("notchwidth", (w * 120) / 1080) * 2);
            float f5 = (float) this.preferences.getInt("notchradiustop", 40);
            float f6 = (float) this.preferences.getInt("notchradiusbottom", 0);
            float f7 = (float) (this.height + 2);
            float f8 = (float) (this.width + 2);
            float f9 = f7 - (f + f);
            float f10 = (f9 - f4) / 2.0f;
            this.preferences.getInt("notchfullnessbottom", 25);
            this.path = new Path();
            this.path.moveTo(f7 - 1.0f, -1.0f + f);
            float f11 = -f;
            this.path.rQuadTo(0.0f, f11, f11, f11);
            if (!this.aBoolean && this.preferences.getBoolean("enablenotch", false)) {
                f9 = (-f10) + f5;
                this.path.rLineTo(f9, 0.0f);
                float f102 = -f5;
                this.path.rQuadTo(f102, 0.0f, f102, f5);
                this.path.rLineTo(0.0f, (f3 - f5) - f6);
                this.path.rLineTo((-f4) + f6 + f6, 0.0f);
                this.path.rLineTo(0.0f, (-f3) + f5 + f6);
                this.path.rQuadTo(0.0f, f102, f102, f102);
                this.path.rLineTo(f9, 0.0f);
                this.path.rQuadTo(f11, 0.0f, f11, f);
                f8 -= f + f2;
                this.path.rLineTo(0.0f, f8);
                this.path.rQuadTo(0.0f, f2, f2, f2);
                this.path.rLineTo(f7 - (f2 + f2), 0.0f);
                this.path.rQuadTo(f2, 0.0f, f2, -f2);
                this.path.rLineTo(0.0f, -f8);
                this.path.close();
                this.path1 = new Path(this.path);
                this.path1.setFillType(Path.FillType.INVERSE_EVEN_ODD);
            }
            this.path.rLineTo(-f9, 0.0f);
            this.path.rQuadTo(f11, 0.0f, f11, f);
            float f82 = f8 - (f + f2);
            this.path.rLineTo(0.0f, f82);
            this.path.rQuadTo(0.0f, f2, f2, f2);
            this.path.rLineTo(f7 - (f2 + f2), 0.0f);
            this.path.rQuadTo(f2, 0.0f, f2, -f2);
            this.path.rLineTo(0.0f, -f82);
            this.path.close();
            this.path1 = new Path(this.path);
            this.path1.setFillType(Path.FillType.INVERSE_EVEN_ODD);
        }

        public void setbgImg() {
            Bitmap decodeFile;
            Context applicationContext = this.cornerWallpaperService.getApplicationContext();
            if (new File(applicationContext.getFilesDir() + File.separator + "bg.png").exists()) {
                decodeFile = BitmapFactory.decodeFile(String.valueOf(applicationContext.getFilesDir()) + File.separator + "bg.png");
            } else {
                decodeFile = BitmapFactory.decodeFile(String.valueOf(applicationContext.getFilesDir()) + File.separator + "bg.png");
            }
            this.bitmap = decodeFile;
        }

        private float time() {
            if (this.mBoolean) {
                return 0.0f;
            }
            if (this.f76b1) {
                return 1.0f;
            }
            if (this.f78i1 - this.f23i < 200000000) {
                return Math.min(1.0f, ((float) ((System.nanoTime() - this.f78i1) / 1000000)) / 120.0f);
            }
            return Math.min(1.0f, ((float) ((System.nanoTime() - this.f78i1) / 1000000)) / 500.0f);
        }

        public void keygauard() {
            if (((KeyguardManager) this.cornerWallpaperService.getApplicationContext().getSystemService("keyguard")).inKeyguardRestrictedInputMode()) {
                this.mBoolean = true;
            } else if (this.mBoolean) {
                this.mBoolean = false;
                this.f78i1 = System.nanoTime();
            }
        }

        public final void onDestroy() {
            super.onDestroy();
            this.handler.removeCallbacks(this.runnable);
        }

        public final void onSurfaceChanged(SurfaceHolder surfaceHolder2, int i, int i2, int i3) {
            super.onSurfaceChanged(surfaceHolder2, i, i2, i3);
            if (this.cornerWallpaperService.getResources().getConfiguration().orientation == 2) {
                this.height = i3;
                this.width = i2;
                this.aBoolean = true;
            } else {
                this.height = i2;
                this.width = i3;
                this.aBoolean = false;
            }
            this.paint2 = new Paint(1);
            this.paint2.setStyle(Paint.Style.FILL);
            this.paint2.setColor(CornerWallpaperService.this.getResources().getColor(R.color.black));
            this.paint = new Paint(1);
            this.paint.setStyle(Paint.Style.STROKE);
            this.paint.setColor(CornerWallpaperService.this.getResources().getColor(R.color.white));
            this.paint1 = new Paint();
            this.paint1.setColor(CornerWallpaperService.this.getResources().getColor(R.color.white));
            this.colorMatrix = new ColorMatrix();
            this.colorMatrix1 = new ColorMatrix();
            this.colorMatrix.postConcat(this.colorMatrix1);
            this.colorMatrixColorFilter = new ColorMatrixColorFilter(this.colorMatrix);
            this.paint1.setColorFilter(this.colorMatrixColorFilter);
            border_shade();
            drawRectPlain();
            this.handler.post(this.f24r);
        }

        public final void onVisibilityChanged(boolean z) {
            this.isTrue = z;
            if (z) {
                this.f23i = System.nanoTime();
                keygauard();
                this.f76b1 = this.mBoolean;
                if (this.f76b1) {
                    this.f78i1 = 0;
                }
                this.handler.post(this.runnable);
                return;
            }
            this.handler.removeCallbacks(this.runnable);
        }
    }

    public Engine onCreateEngine() {
        return new MyEngine(this);
    }
}
