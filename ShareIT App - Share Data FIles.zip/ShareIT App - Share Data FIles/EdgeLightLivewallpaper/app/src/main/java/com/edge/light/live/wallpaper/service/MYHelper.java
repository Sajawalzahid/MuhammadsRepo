package com.edge.light.live.wallpaper.service;

import android.app.Application;

public class MYHelper extends Application {
    public static String share_pref_key = "com.edge.light.live.wallpaper.service";
}
