package com.edge.light.live.wallpaper;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
//import android.support.p003v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.edge.light.live.wallpaper.Tools.AppAdOrganizer;
import com.edge.light.live.wallpaper.service.CornerWallpaperService;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;

import java.io.IOException;
import java.util.Objects;

import static com.edge.light.live.wallpaper.Tools.AppTimeHandler.appStructureBase;

public class CustomHomeActivity extends AppCompatActivity {
    ImageView back;
    ImageView edge_setting;


    int f55h;
    ImageView preview;
    ImageView set_background;
    ImageView set_wallpaper;
    TextView title;
    Typeface typeface;


    int f56w;


    FrameLayout googleadViewNative;
    private NativeAdLayout nativeAdLayout;
    private UnifiedNativeAd nativeAd;
    private NativeAd fbnativeAd;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_custom_home);
        googleadViewNative = findViewById(R.id.gooogleadViewNative);
        nativeAdLayout = findViewById(R.id.fbnative_ad_container);
        if (appStructureBase != null && appStructureBase.getFb_native_option1() == 1) {

            fbnativeAd = new NativeAd(this, appStructureBase.getFb_native_id());
            NativeAdBase.NativeLoadAdConfig nativeLoadAdConfig = fbnativeAd
                    .buildLoadAdConfig()
                    .withAdListener(new NativeAdListener() {
                        @SuppressLint("LongLogTag")
                        @Override
                        public void onMediaDownloaded(Ad ad) {
                        }

                        @Override
                        public void onError(Ad ad, AdError adError) {
                        }

                        @Override
                        public void onAdLoaded(Ad ad) {

                            try {

                                if (fbnativeAd == null || fbnativeAd != ad) {
                                    return;
                                }
                                AppAdOrganizer.getInstance().inflateAd(CustomHomeActivity.this, fbnativeAd, nativeAdLayout);
                                nativeAdLayout.setVisibility(View.VISIBLE);
                            } catch (Exception ignored) {

                            }
                        }

                        @Override
                        public void onAdClicked(Ad ad) {
                        }

                        @Override
                        public void onLoggingImpression(Ad ad) {
                        }
                    }).build();

            fbnativeAd.loadAd(nativeLoadAdConfig);

        }
        else if (appStructureBase != null && appStructureBase.getGoogle_native_option1() == 1) {

            AdLoader adLoader = new AdLoader.Builder(Objects.requireNonNull(this), appStructureBase.getNative_id())
                    .forUnifiedNativeAd(unifiedNativeAd -> {
                        googleadViewNative.setVisibility(View.VISIBLE);
                        try {
                            if (nativeAd != null) {
                                nativeAd.destroy();
                            }
                            nativeAd = unifiedNativeAd;
                            @SuppressLint("InflateParams")
                            UnifiedNativeAdView adView = (UnifiedNativeAdView) LayoutInflater.from(this).inflate(R.layout.ad_unified, null);
                            AppAdOrganizer.getInstance().loadAdMobNativeAd(unifiedNativeAd, adView);
                            googleadViewNative.removeAllViews();
                            googleadViewNative.addView(adView);
                        } catch (Exception ignored) {

                        }
                    }).build();
            adLoader.loadAd(new AdRequest.Builder().build());

        } else {
            nativeAdLayout.setVisibility(View.GONE);
            googleadViewNative.setVisibility(View.GONE);
        }
        this.f56w = getResources().getDisplayMetrics().widthPixels;
        this.f55h = getResources().getDisplayMetrics().heightPixels;
        this.title = (TextView) findViewById(R.id.title);
        this.back = (ImageView) findViewById(R.id.back);
        this.set_wallpaper = (ImageView) findViewById(R.id.set_wallpaper);
        this.preview = (ImageView) findViewById(R.id.preview);
        this.edge_setting = (ImageView) findViewById(R.id.edge_setting);
        this.set_background = (ImageView) findViewById(R.id.set_background);
        this.typeface = Typeface.createFromAsset(getAssets(), "Franklin Gothic Book Regular.ttf");
        this.title.setTypeface(this.typeface);
        this.set_wallpaper.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    CustomHomeActivity.this.clearWallpaper();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Intent intent = new Intent("android.service.wallpaper.CHANGE_LIVE_WALLPAPER");
                intent.putExtra("android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT", new ComponentName(CustomHomeActivity.this, CornerWallpaperService.class));
                try {
                    loadFBAd(CustomHomeActivity.this, intent);
                } catch (Exception ignored) {
                }
            }
        });
        this.preview.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
//                CustomHomeActivity.this.startActivity(new Intent(CustomHomeActivity.this.getApplicationContext(), PreviewActivity.class));
                Intent intent = new Intent(CustomHomeActivity.this, PreviewActivity.class);

                try {
                    loadFBAd(CustomHomeActivity.this, intent);
                } catch (Exception ignored) {
                }
            }
        });
        this.edge_setting.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
//                CustomHomeActivity.this.startActivity(new Intent(CustomHomeActivity.this.getApplicationContext(), SettingActivity.class));
                Intent intent = new Intent(CustomHomeActivity.this, SettingActivity.class);

                try {
                    loadFBAd(CustomHomeActivity.this, intent);
                } catch (Exception ignored) {
                }
            }
        });
        this.set_background.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
//                CustomHomeActivity.this.startActivity(new Intent(CustomHomeActivity.this.getApplicationContext(), SetBackgroundActivity.class));
                Intent intent = new Intent(CustomHomeActivity.this, SetBackgroundActivity.class);

                try {
                    loadFBAd(CustomHomeActivity.this, intent);
                } catch (Exception ignored) {
                }
            }
        });
        this.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CustomHomeActivity.this.onBackPressed();
            }
        });
        setLayout();
    }

    private void loadFBAd(final Activity activity, final Intent intent) {
        try {

            if (appStructureBase.getFb_inter_home() == 1) {
                final CustomProgressDialog customProgressDialog = new CustomProgressDialog(activity);
                customProgressDialog.setCancelable(false);
                customProgressDialog.show();

                AppAdOrganizer
                        .getInstance()
                        .getfbAdMobInstance(activity)
                        .buildLoadAdConfig()
                        .withAdListener(new InterstitialAdListener() {
                            @Override
                            public void onInterstitialDisplayed(Ad ad) {
                            }

                            @Override
                            public void onInterstitialDismissed(Ad ad) {
                                long currentTimeInSecs = System.currentTimeMillis();

                                try {
                                    startActivity(intent);
                                } catch (Exception ignored) {
                                }
                            }

                            @Override
                            public void onError(Ad ad, AdError adError) {
                                long currentTimeInSecs = System.currentTimeMillis();

                                startActivity(intent);
                                customProgressDialog.dismiss();

                            }

                            @Override
                            public void onAdLoaded(Ad ad) {
                                try {
                                    customProgressDialog.dismiss();
                                    AppAdOrganizer.getInstance().getfbAdMobInstance(activity).show();
                                } catch (Exception ignored) {
                                }
                            }

                            @Override
                            public void onAdClicked(Ad ad) {
                            }

                            @Override
                            public void onLoggingImpression(Ad ad) {
                            }
                        })
                        .build();
                AppAdOrganizer.getInstance().getfbAdMobInstance(activity).loadAd();


            } else {
                loadAmbAd(activity, intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAmbAd(final Activity activity, final Intent intent) {
        if (appStructureBase.getGoogle_inter_home() == 1) {
            if (AppAdOrganizer.getInstance().getAdMobInstance(activity).isLoaded()) {
                AppAdOrganizer.getInstance().getAdMobInstance(activity)
                        .setAdListener(new AdListener() {
                            @Override
                            public void onAdClosed() {
                                try {
                                    AppAdOrganizer.getInstance().getAdMobInstance(activity).setAdListener(new AdListener());
                                    AppAdOrganizer.getInstance().loadAdMobAd();

                                    startActivity(intent);
                                } catch (Exception ignored) {
                                }
                            }
                        });

                AppAdOrganizer.getInstance().getAdMobInstance(activity).show();
            } else {
                if (!AppAdOrganizer.getInstance().getAdMobInstance(activity).isLoading()) {
                    AppAdOrganizer.getInstance().getAdMobInstance(activity).setAdListener(new AdListener());
                    AppAdOrganizer.getInstance().loadAdMobAd();
                }
                activity.startActivity(intent);
            }
        } else {
            activity.startActivity(intent);
        }
    }

    public void setLayout() {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.f56w * 60) / 1080, (this.f56w * 60) / 1080);
        params.addRule(13);
        this.back.setLayoutParams(params);
        LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams((this.f56w * 647) / 1080, (this.f56w * 142) / 1080);
        int m = (this.f56w * 50) / 1080;
        params1.setMargins(0, m, 0, m);
        this.set_wallpaper.setLayoutParams(params1);
        this.set_background.setLayoutParams(params1);
        this.edge_setting.setLayoutParams(params1);
        this.preview.setLayoutParams(params1);
    }
}
