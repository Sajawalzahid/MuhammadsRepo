package com.edge.light.live.wallpaper;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
//import android.support.annotation.NonNull;
//import android.support.p000v4.content.ContextCompat;
//import android.support.p003v7.app.AppCompatActivity;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.dingmouren.videowallpaper.VideoWallpaper;
import com.edge.light.live.wallpaper.Tools.AppAdOrganizer;
import com.edge.light.live.wallpaper.adapter.ImageListAdapter;
import com.edge.light.live.wallpaper.cropper.CropImage;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.InterstitialAdListener;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeBannerAd;
import com.google.android.gms.ads.AdListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

import static com.edge.light.live.wallpaper.Tools.AppTimeHandler.appStructureBase;

public class MainActivity extends AppCompatActivity {
    ImageView custom;


    int f59h;
    String[] permission = {"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.SET_WALLPAPER"};
    ImageView splash_text;
    ImageView start;


    int f60w;




    //copy
    ImageListAdapter adapter;
//    ImageView back;
    int f57h;
    GridView list;
    VideoWallpaper mVideoWallpaper;
    ProgressDialog progress;
    ImageView sc2_text;
    String[] thumb;
//    TextView title;
    Typeface typeface;
    String[] videos;
    View view_above;
    View view_below;
    int f58w;


    private NativeAdLayout fbnativeAdLayout;
    private NativeBannerAd fbnativeBannerAd;
    FrameLayout adrelative;
    private AdView adView;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_main);

        this.f60w = getResources().getDisplayMetrics().widthPixels;
        this.f59h = getResources().getDisplayMetrics().heightPixels;
        this.splash_text = (ImageView) findViewById(R.id.splash_text);
        this.start = (ImageView) findViewById(R.id.start);
        this.custom = (ImageView) findViewById(R.id.custom);

        fbnativeAdLayout = findViewById(R.id.fbnative_banner_ad_container);
        adrelative = findViewById(R.id.adrelative);
        FrameLayout adViewAdaptiveBanner = findViewById(R.id.adViewAdaptiveBanner);

        if (appStructureBase.getFb_banner_home() == 1) {
            fbnativeAdLayout.setVisibility(View.VISIBLE);
            adrelative.setVisibility(View.VISIBLE);
            adView = new AdView(this, appStructureBase.getFb_banner_id(), AdSize.BANNER_HEIGHT_50);
            fbnativeAdLayout.addView(adView);
            adView.loadAd();

        } else if(appStructureBase.getGoogle_banner_home() == 1) {
            AppAdOrganizer.getInstance().loadAdMobBannerAd(MainActivity.this, adViewAdaptiveBanner, AppAdOrganizer.getInstance().getAdSize(Objects.requireNonNull(MainActivity.this), adViewAdaptiveBanner));
            adViewAdaptiveBanner.setVisibility(View.VISIBLE);
            adrelative.setVisibility(View.VISIBLE);
        }else {
            adViewAdaptiveBanner.setVisibility(View.GONE);
            fbnativeAdLayout.setVisibility(View.GONE);
            adrelative.setVisibility(View.GONE);
        }
//        this.start.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), ListActivity.class));
//            }
//        });
        this.custom.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
//                MainActivity.this.startActivity(new Intent(MainActivity.this.getApplicationContext(), CustomHomeActivity.class));
                Intent intent = new Intent(MainActivity.this, CustomHomeActivity.class);

                try {
                    loadFBAd(MainActivity.this, intent);
                } catch (Exception ignored) {
                }
            }
        });
        AllowPermission();
        setLayout();
//        AppAdOrganizer.getInstance().getAdMobInstance(MainActivity.this).setAdListener(new AdListener());
//        AppAdOrganizer.getInstance().loadAdMobAd();




        //copy
        this.f58w = getResources().getDisplayMetrics().widthPixels;
        this.f57h = getResources().getDisplayMetrics().heightPixels;
        this.progress = new ProgressDialog(this);
        this.progress.setMessage("Loading...");
        this.progress.setCancelable(false);
        this.mVideoWallpaper = new VideoWallpaper();
//        this.back = (ImageView) findViewById(R.id.back);
        this.sc2_text = (ImageView) findViewById(R.id.sc2_text);
        this.view_below = findViewById(R.id.view_below);
        this.view_above = findViewById(R.id.view_above);
        this.list = (GridView) findViewById(R.id.rcvbg);
//        this.title = (TextView) findViewById(R.id.title);
        this.typeface = Typeface.createFromAsset(getAssets(), "Franklin Gothic Book Regular.ttf");
//        this.title.setTypeface(this.typeface);
        try {
            this.thumb = getAssets().list("thumb");
            this.videos = getAssets().list("videos");
        } catch (Exception e) {
//            e.toString();
            Toast.makeText(mVideoWallpaper, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        this.adapter = new ImageListAdapter(this, this.thumb);
        this.list.setAdapter(this.adapter);
        this.list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                listclickloadFBAd(MainActivity.this,position);
            }
        });
//        this.back.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                MainActivity.this.onBackPressed();
//            }
//        });
        setLayout();
    }





    public void writeMp4ToNative(File file, InputStream is) {
        try {
            FileOutputStream os = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            while (is.read(buffer) != -1) {
                os.write(buffer, 0, buffer.length);
            }
            os.flush();
            os.close();
            is.close();
            this.mVideoWallpaper.setToWallPaper(this, file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
//            Toast.makeText(this, "Something went Wrong...", 0).show();
        }
    }

    class CopyFile extends AsyncTask<String, String, String> {
        int position;

        CopyFile(int pos) {
            this.position = pos;
        }


        public void onPreExecute() {
            try {
                MainActivity.this.progress.show();
            } catch (Exception e) {
                e.toString();
            }
            super.onPreExecute();
        }


        public void onPostExecute(String result) {
            try {
                MainActivity.this.progress.dismiss();
            } catch (Exception e) {
                e.toString();
            }
            super.onPostExecute(result);
        }


        public String doInBackground(String... params) {
            File mFile2 = new File(Environment.getExternalStorageDirectory() + "/" + MainActivity.this.getResources().getString(R.string.app_name));
            mFile2.mkdirs();
            File mFile22 = new File(mFile2.getAbsoluteFile() + "/wallvideo.mp4");
//            try {
            try {
                mFile22.createNewFile();
            }
            catch (IOException e) {
                Log.e("====error",e.getMessage());
                e.printStackTrace();
            }
            try {
                MainActivity.this.writeMp4ToNative(mFile22, MainActivity.this.getAssets().open("videos/" + MainActivity.this.videos[this.position]));
            }
            catch (IOException e) {
                Log.e("====errora",e.getMessage());
                e.printStackTrace();
            }
            return null;
//            } catch (IOException e) {
//                e.printStackTrace();
//                return null;
//            }
        }
    }

    public void setLayout() {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.f60w * 620) / 1080, (this.f60w * 281) / 1080);
        params.addRule(13);
//        this.splash_text.setLayoutParams(params);
//        LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams((this.f60w * 758) / 1080, (this.f60w * 164) / 1080);
//        int m = (this.f60w * 50) / 1080;
//        params1.setMargins(0, m, 0, m);
//        this.start.setLayoutParams(params1);
//        this.custom.setLayoutParams(params1);
//        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.f58w * 60) / 1080, (this.f58w * 60) / 1080);
//        params.addRule(13);
////        this.back.setLayoutParams(params);
//        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.f58w * 633) / 1080, (this.f58w * 165) / 1080);
//        int m = (this.f58w * CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE) / 1080;
//        params1.setMargins(0, m, 0, m);
//        params1.addRule(14);
//        this.sc2_text.setLayoutParams(params1);
//        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(-1, (this.f58w * 360) / 1080);
//        params2.addRule(12);
//        this.view_below.setLayoutParams(params2);
//        this.view_above.setLayoutParams(new RelativeLayout.LayoutParams(-1, (this.f58w * 360) / 1080));
    }


    public void AllowPermission() {
        if (Build.VERSION.SDK_INT < 23) {
            return;
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") != 0 || ContextCompat.checkSelfPermission(this, "android.permission.SET_WALLPAPER") != 0 || ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            requestPermissions(this.permission, 100);
        }
    }
    private void loadFBAd(final Activity activity, final Intent intent) {
        try {

            if (appStructureBase.getFb_inter_home() == 1) {
                final CustomProgressDialog customProgressDialog = new CustomProgressDialog(activity);
                customProgressDialog.setCancelable(false);
                customProgressDialog.show();

                AppAdOrganizer
                        .getInstance()
                        .getfbAdMobInstance(activity)
                        .buildLoadAdConfig()
                        .withAdListener(new InterstitialAdListener() {
                            @Override
                            public void onInterstitialDisplayed(Ad ad) {
                            }

                            @Override
                            public void onInterstitialDismissed(Ad ad) {
                                long currentTimeInSecs = System.currentTimeMillis();

                                try {
                                    startActivity(intent);
                                } catch (Exception ignored) {
                                }
                            }

                            @Override
                            public void onError(Ad ad, AdError adError) {
                                long currentTimeInSecs = System.currentTimeMillis();

                                startActivity(intent);
                                customProgressDialog.dismiss();

                            }

                            @Override
                            public void onAdLoaded(Ad ad) {
                                try {
                                    customProgressDialog.dismiss();
                                    AppAdOrganizer.getInstance().getfbAdMobInstance(activity).show();
                                } catch (Exception ignored) {
                                }
                            }

                            @Override
                            public void onAdClicked(Ad ad) {
                            }

                            @Override
                            public void onLoggingImpression(Ad ad) {
                            }
                        })
                        .build();
                AppAdOrganizer.getInstance().getfbAdMobInstance(activity).loadAd();


            } else {
                loadAmbAd(activity, intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAmbAd(final Activity activity, final Intent intent) {
        if (appStructureBase.getGoogle_inter_home() == 1) {
            if (AppAdOrganizer.getInstance().getAdMobInstance(activity).isLoaded()) {
                AppAdOrganizer.getInstance().getAdMobInstance(activity)
                        .setAdListener(new AdListener() {
                            @Override
                            public void onAdClosed() {
                                try {
                                    AppAdOrganizer.getInstance().getAdMobInstance(activity).setAdListener(new AdListener());
                                    AppAdOrganizer.getInstance().loadAdMobAd();

                                    startActivity(intent);
                                } catch (Exception ignored) {
                                }
                            }
                        });

                AppAdOrganizer.getInstance().getAdMobInstance(activity).show();
            } else {
                if (!AppAdOrganizer.getInstance().getAdMobInstance(activity).isLoading()) {
                    AppAdOrganizer.getInstance().getAdMobInstance(activity).setAdListener(new AdListener());
                    AppAdOrganizer.getInstance().loadAdMobAd();
                }
                activity.startActivity(intent);
            }
        } else {
            activity.startActivity(intent);
        }
    }

    private void listclickloadFBAd(final Activity activity, int position) {
        try {

            if (appStructureBase.getFb_inter_home() == 1) {
                final CustomProgressDialog customProgressDialog = new CustomProgressDialog(activity);
                customProgressDialog.setCancelable(false);
                customProgressDialog.show();

                AppAdOrganizer
                        .getInstance()
                        .getfbAdMobInstance(activity)
                        .buildLoadAdConfig()
                        .withAdListener(new InterstitialAdListener() {
                            @Override
                            public void onInterstitialDisplayed(Ad ad) {
                            }

                            @Override
                            public void onInterstitialDismissed(Ad ad) {
                                long currentTimeInSecs = System.currentTimeMillis();

                                try {
                                    new MainActivity.CopyFile(position).execute(new String[0]);

                                } catch (Exception ignored) {
                                }
                            }

                            @Override
                            public void onError(Ad ad, AdError adError) {
                                long currentTimeInSecs = System.currentTimeMillis();

                                new MainActivity.CopyFile(position).execute(new String[0]);

                                customProgressDialog.dismiss();

                            }

                            @Override
                            public void onAdLoaded(Ad ad) {
                                try {
                                    customProgressDialog.dismiss();
                                    AppAdOrganizer.getInstance().getfbAdMobInstance(activity).show();
                                } catch (Exception ignored) {
                                }
                            }

                            @Override
                            public void onAdClicked(Ad ad) {
                            }

                            @Override
                            public void onLoggingImpression(Ad ad) {
                            }
                        })
                        .build();
                AppAdOrganizer.getInstance().getfbAdMobInstance(activity).loadAd();


            } else {
                listclickloadAmbAd(activity, position);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void listclickloadAmbAd(final Activity activity,int position) {
        if (appStructureBase.getGoogle_inter_home() == 1) {
            if (AppAdOrganizer.getInstance().getAdMobInstance(activity).isLoaded()) {
                AppAdOrganizer.getInstance().getAdMobInstance(activity)
                        .setAdListener(new AdListener() {
                            @Override
                            public void onAdClosed() {
                                try {
                                    AppAdOrganizer.getInstance().getAdMobInstance(activity).setAdListener(new AdListener());
                                    AppAdOrganizer.getInstance().loadAdMobAd();

                                    new MainActivity.CopyFile(position).execute(new String[0]);

                                } catch (Exception ignored) {
                                }
                            }
                        });

                AppAdOrganizer.getInstance().getAdMobInstance(activity).show();
            } else {
                if (!AppAdOrganizer.getInstance().getAdMobInstance(activity).isLoading()) {
                    AppAdOrganizer.getInstance().getAdMobInstance(activity).setAdListener(new AdListener());
                    AppAdOrganizer.getInstance().loadAdMobAd();
                }
                new MainActivity.CopyFile(position).execute(new String[0]);

            }
        } else {
            new MainActivity.CopyFile(position).execute(new String[0]);

        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        AllowPermission();
    }
}
