package com.edge.light.live.wallpaper;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
//import android.support.p003v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.edge.light.live.wallpaper.Tools.AppAdOrganizer;
import com.edge.light.live.wallpaper.holocolorpicker.ColorPicker;
import com.edge.light.live.wallpaper.holocolorpicker.OpacityBar;
import com.edge.light.live.wallpaper.holocolorpicker.SVBar;
import com.edge.light.live.wallpaper.service.MYHelper;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.NativeAdLayout;

import java.util.Objects;
import java.util.Set;

import static com.edge.light.live.wallpaper.Tools.AppTimeHandler.appStructureBase;

public class SettingActivity extends AppCompatActivity {
    SeekBar animation_seek;
    ImageView back;
    int clr1;
    int clr2;
    int clr3;
    int clr4;
    ImageView color1;
    ImageView color2;
    ImageView color3;
    ImageView color4;
    SeekBar curve_bottom_seek;
    SeekBar curve_top_seek;


    int f70h;
    ImageView img_anim_box;
    ImageView img_anim_speed;
    ImageView img_curve_bottom;
    ImageView img_curve_bottom_box;
    ImageView img_curve_top;
    ImageView img_curve_top_box;
    ImageView img_edge_color;
    ImageView img_edge_color_box;
    ImageView img_enable;
    ImageView img_notch_setting_box;
    ImageView img_thick;
    ImageView img_thick_box;
    LinearLayout lay1;
    SeekBar notch_height_seek;
    SeekBar notch_width_seek;
    SharedPreferences pref;
    SeekBar thickness_seek;
    TextView title;
    TextView txt_anim_speed;
    TextView txt_curve_bottom;
    TextView txt_curve_top;
    TextView txt_notch_height;
    TextView txt_notch_width;
    TextView txt_thickness;
    Typeface typeface;


    int f71w;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_setting);
        this.pref = getSharedPreferences(MYHelper.share_pref_key, 0);
        NativeAdLayout fbnativeAdLayout = findViewById(R.id.fbnative_banner_ad_container);
        FrameLayout adrelative = findViewById(R.id.adrelative);
        FrameLayout adViewAdaptiveBanner = findViewById(R.id.adViewAdaptiveBanner);

        if (appStructureBase.getFb_banner_option2() == 1) {
            fbnativeAdLayout.setVisibility(View.VISIBLE);
            adrelative.setVisibility(View.VISIBLE);
            AdView adView = new AdView(this, appStructureBase.getFb_banner_id(), AdSize.BANNER_HEIGHT_50);
            fbnativeAdLayout.addView(adView);
            adView.loadAd();

        } else if(appStructureBase.getGoogle_banner_option2() == 1) {
            AppAdOrganizer.getInstance().loadAdMobBannerAd(SettingActivity.this, adViewAdaptiveBanner, AppAdOrganizer.getInstance().getAdSize(Objects.requireNonNull(SettingActivity.this), adViewAdaptiveBanner));
            adViewAdaptiveBanner.setVisibility(View.VISIBLE);
            adrelative.setVisibility(View.VISIBLE);
        }else {
            adViewAdaptiveBanner.setVisibility(View.GONE);
            fbnativeAdLayout.setVisibility(View.GONE);
            adrelative.setVisibility(View.GONE);
        }
        this.f71w = getResources().getDisplayMetrics().widthPixels;
        this.f70h = getResources().getDisplayMetrics().heightPixels;
        this.title = (TextView) findViewById(R.id.title);
        this.back = (ImageView) findViewById(R.id.back);
        this.txt_anim_speed = (TextView) findViewById(R.id.txt_anim_speed);
        this.txt_thickness = (TextView) findViewById(R.id.txt_thickness);
        this.txt_curve_top = (TextView) findViewById(R.id.txt_curve_top);
        this.txt_curve_bottom = (TextView) findViewById(R.id.txt_curve_bottom);
        this.animation_seek = (SeekBar) findViewById(R.id.animation_seek);
        this.thickness_seek = (SeekBar) findViewById(R.id.thickness_seek);
        this.curve_top_seek = (SeekBar) findViewById(R.id.curve_top_seek);
        this.curve_bottom_seek = (SeekBar) findViewById(R.id.curve_bottom_seek);
        this.color1 = (ImageView) findViewById(R.id.color1);
        this.color2 = (ImageView) findViewById(R.id.color2);
        this.color3 = (ImageView) findViewById(R.id.color3);
        this.color4 = (ImageView) findViewById(R.id.color4);
        this.lay1 = (LinearLayout) findViewById(R.id.lay1);
        this.img_enable = (ImageView) findViewById(R.id.img_enable);
        this.txt_notch_width = (TextView) findViewById(R.id.txt_notch_width);
        this.txt_notch_height = (TextView) findViewById(R.id.txt_notch_height);
        this.notch_width_seek = (SeekBar) findViewById(R.id.notch_width_seek);
        this.notch_height_seek = (SeekBar) findViewById(R.id.notch_height_seek);
        this.img_anim_speed = (ImageView) findViewById(R.id.img_anim_speed);
        this.img_thick = (ImageView) findViewById(R.id.img_thick);
        this.img_curve_top = (ImageView) findViewById(R.id.img_curve_top);
        this.img_curve_bottom = (ImageView) findViewById(R.id.img_curve_bottom);
        this.img_edge_color = (ImageView) findViewById(R.id.img_edge_color);
        this.img_notch_setting_box = (ImageView) findViewById(R.id.img_notch_setting_box);
        this.img_anim_box = (ImageView) findViewById(R.id.img_anim_box);
        this.img_thick_box = (ImageView) findViewById(R.id.img_thick_box);
        this.img_curve_top_box = (ImageView) findViewById(R.id.img_curve_top_box);
        this.img_curve_bottom_box = (ImageView) findViewById(R.id.img_curve_bottom_box);
        this.img_edge_color_box = (ImageView) findViewById(R.id.img_edge_color_box);
        this.typeface = Typeface.createFromAsset(getAssets(), "Franklin Gothic Book Regular.ttf");
        this.title.setTypeface(this.typeface);
        this.txt_anim_speed.setTypeface(this.typeface);
        this.txt_thickness.setTypeface(this.typeface);
        this.txt_curve_top.setTypeface(this.typeface);
        this.txt_curve_bottom.setTypeface(this.typeface);
        this.txt_notch_width.setTypeface(this.typeface);
        this.txt_notch_height.setTypeface(this.typeface);
        this.animation_seek.setMax(20);
        this.thickness_seek.setMax((this.f71w * 60) / 1080);
        this.curve_top_seek.setMax((this.f71w * 180) / 1080);
        this.curve_bottom_seek.setMax((this.f71w * 180) / 1080);
        int thiknesssize = (this.f71w * 20) / 1080;
        int curvetop = (this.f71w * 60) / 1080;
        int curvebottom = (this.f71w * 60) / 1080;
        this.animation_seek.setProgress(this.pref.getInt("animationspeed", 20));
        this.thickness_seek.setProgress(this.pref.getInt("thiknesssize", thiknesssize));
        this.curve_top_seek.setProgress(this.pref.getInt("curvetop", curvetop));
        this.curve_bottom_seek.setProgress(this.pref.getInt("curvebottom", curvebottom));
        seekmethod(this.animation_seek, "animationspeed");
        seekmethod(this.thickness_seek, "thiknesssize");
        seekmethod(this.curve_top_seek, "curvetop");
        seekmethod(this.curve_bottom_seek, "curvebottom");
        this.notch_width_seek.setMax((this.f71w * 240) / 1080);
        this.notch_height_seek.setMax((this.f71w * 150) / 1080);
        int notchwidth = (this.f71w * 120) / 1080;
        int notchheight = (this.f71w * 75) / 1080;
        this.notch_width_seek.setProgress(this.pref.getInt("notchwidth", notchwidth));
        this.notch_height_seek.setProgress(this.pref.getInt("notchheight", notchheight));
        notchseekMethod(this.notch_width_seek, "notchwidth");
        notchseekMethod(this.notch_height_seek, "notchheight");
        this.color1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SettingActivity.this.color_dialog(SettingActivity.this.clr1, "color.1");
            }
        });
        this.color2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SettingActivity.this.color_dialog(SettingActivity.this.clr2, "color.2");
            }
        });
        this.color3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SettingActivity.this.color_dialog(SettingActivity.this.clr3, "color.3");
            }
        });
        this.color4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SettingActivity.this.color_dialog(SettingActivity.this.clr4, "color.4");
            }
        });
        this.lay1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (SettingActivity.this.pref.getBoolean("enablenotch", false)) {
                    SettingActivity.this.pref.edit().putBoolean("enablenotch", false).apply();
                } else {
                    SettingActivity.this.pref.edit().putBoolean("enablenotch", true).apply();
                }
                SettingActivity.this.check();
            }
        });
        this.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SettingActivity.this.onBackPressed();
            }
        });
        check();
        setLayout();
    }


    public void setLayout() {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.f71w * 60) / 1080, (this.f71w * 60) / 1080);
        params.addRule(13);
        this.back.setLayoutParams(params);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.f71w * 80) / 1080, (this.f71w * 39) / 1080);
        params1.addRule(13);
        this.img_enable.setLayoutParams(params1);
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams((this.f71w * 604) / 1080, (this.f71w * 112) / 1080);
        params2.addRule(14);
        params2.setMargins(0, (this.f71w * 100) / 1080, 0, 0);
        this.img_anim_speed.setLayoutParams(params2);
        this.img_thick.setLayoutParams(params2);
        this.img_curve_top.setLayoutParams(params2);
        this.img_curve_bottom.setLayoutParams(params2);
        this.img_edge_color.setLayoutParams(params2);
        this.lay1.setLayoutParams(params2);
        Bitmap thumb = BitmapFactory.decodeResource(getResources(), R.drawable.seekbar_controller_green);
        Bitmap thumb2 = BitmapFactory.decodeResource(getResources(), R.drawable.seekbar_controller_sky);
        int sw = (this.f71w * thumb.getWidth()) / 1080;
        int sw1 = (this.f71w * thumb2.getWidth()) / 1080;
        Bitmap thumb3 = Bitmap.createScaledBitmap(thumb, sw, sw, true);
        Bitmap thumb22 = Bitmap.createScaledBitmap(thumb2, sw1, sw1, true);
        this.animation_seek.setThumb(new BitmapDrawable(getResources(), thumb3));
        this.thickness_seek.setThumb(new BitmapDrawable(getResources(), thumb22));
        this.curve_top_seek.setThumb(new BitmapDrawable(getResources(), thumb3));
        this.curve_bottom_seek.setThumb(new BitmapDrawable(getResources(), thumb22));
        this.notch_width_seek.setThumb(new BitmapDrawable(getResources(), thumb22));
        this.notch_height_seek.setThumb(new BitmapDrawable(getResources(), thumb22));
        set_box(this.img_anim_box, R.id.img_anim_speed);
        set_box(this.img_thick_box, R.id.img_thick);
        set_box(this.img_curve_top_box, R.id.img_curve_top);
        set_box(this.img_curve_bottom_box, R.id.img_curve_bottom);
        set_box(this.img_edge_color_box, R.id.img_edge_color);
        LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams((this.f71w * 80) / 1080, (this.f71w * 80) / 1080);
        int mlr = (this.f71w * 30) / 1080;
        params3.setMargins(mlr, (this.f71w * 70) / 1080, mlr, 0);
        this.color1.setLayoutParams(params3);
        this.color2.setLayoutParams(params3);
        this.color3.setLayoutParams(params3);
        this.color4.setLayoutParams(params3);
        RelativeLayout.LayoutParams params4 = new RelativeLayout.LayoutParams((this.f71w * 930) / 1080, (this.f71w * 430) / 1080);
        params4.addRule(14);
        params4.addRule(3, R.id.lay1);
        params4.setMargins(0, -((this.f71w * 56) / 1080), 0, (this.f71w * 100) / 1080);
        this.img_notch_setting_box.setLayoutParams(params4);
    }


    public void set_box(View box, int id) {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.f71w * 930) / 1080, (this.f71w * 262) / 1080);
        params.addRule(14);
        params.addRule(3, id);
        params.setMargins(0, -((this.f71w * 56) / 1080), 0, 0);
        box.setLayoutParams(params);
    }


    public void check() {
        this.clr1 = this.pref.getInt("color.1", Color.argb(255, 236, 243, 27));
        this.clr2 = this.pref.getInt("color.2", Color.argb(255, 42, 146, 65));
        this.clr3 = this.pref.getInt("color.3", Color.argb(255, 180, 6, 183));
        this.clr4 = this.pref.getInt("color.4", Color.argb(255, 38, 36, 122));
        this.color1.setColorFilter(this.clr1);
        this.color2.setColorFilter(this.clr2);
        this.color3.setColorFilter(this.clr3);
        this.color4.setColorFilter(this.clr4);
        if (this.pref.getBoolean("enablenotch", false)) {
            this.img_enable.setImageResource(R.drawable.toggle_on);
        } else {
            this.img_enable.setImageResource(R.drawable.toggle_off);
        }
    }


    public void seekmethod(SeekBar seekbar, final String str) {
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public final void onStartTrackingTouch(SeekBar seekBar) {
            }

            public final void onStopTrackingTouch(SeekBar seekBar) {
            }

            public final void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                SettingActivity.this.pref.edit().putInt(str, i).apply();
            }
        });
    }


    public void notchseekMethod(SeekBar seekbar, final String str) {
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public final void onStartTrackingTouch(SeekBar seekBar) {
            }

            public final void onStopTrackingTouch(SeekBar seekBar) {
            }

            public final void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                SettingActivity.this.pref.edit().putInt(str, i).apply();
            }
        });
    }


    public void color_dialog(int colorcode, String str) {
        final Dialog dialog = new Dialog(this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.pop_color);
        ((LinearLayout) dialog.findViewById(R.id.mainLay)).setLayoutParams(new RelativeLayout.LayoutParams((this.f71w * 824) / 1080, (this.f71w * 1031) / 1080));
        ImageView cancel = (ImageView) dialog.findViewById(R.id.cancel);
        ImageView submit = (ImageView) dialog.findViewById(R.id.ok);
        ImageView close = (ImageView) dialog.findViewById(R.id.close);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.f71w * 273) / 1080, (this.f71w * 87) / 1080);
        params1.addRule(14);
        cancel.setLayoutParams(params1);
        submit.setLayoutParams(params1);
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams((this.f71w * 85) / 1080, (this.f71w * 85) / 1080);
        params2.addRule(11);
        params2.addRule(15);
        params2.setMargins(0, 0, (this.f71w * 30) / 1080, 0);
        close.setLayoutParams(params2);
        final ColorPicker picker = (ColorPicker) dialog.findViewById(R.id.picker);
        SVBar svBar = (SVBar) dialog.findViewById(R.id.svbar);
        OpacityBar opacityBar = (OpacityBar) dialog.findViewById(R.id.opacitybar);
        LinearLayout.LayoutParams params4 = new LinearLayout.LayoutParams((this.f71w * 500) / 1080, (this.f71w * 500) / 1080);
        params4.gravity = 17;
        picker.setLayoutParams(params4);
        picker.addSVBar(svBar);
        picker.addOpacityBar(opacityBar);
        picker.setOldCenterColor(colorcode);
        picker.setColor(colorcode);
        svBar.setColor(colorcode);
        opacityBar.setColor(colorcode);
        cancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dialog.cancel();
            }
        });
        final String str2 = str;
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SettingActivity.this.pref.edit().putInt(str2, picker.getColor()).apply();
                SettingActivity.this.check();
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
