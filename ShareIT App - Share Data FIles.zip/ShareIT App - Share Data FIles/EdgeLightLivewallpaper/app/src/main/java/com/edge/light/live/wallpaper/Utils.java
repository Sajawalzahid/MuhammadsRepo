package com.edge.light.live.wallpaper;

import android.graphics.Bitmap;
import android.net.Uri;

class Utils {
    public static Bitmap bitmap;
    public static Uri uri;

    Utils() {
    }
}
