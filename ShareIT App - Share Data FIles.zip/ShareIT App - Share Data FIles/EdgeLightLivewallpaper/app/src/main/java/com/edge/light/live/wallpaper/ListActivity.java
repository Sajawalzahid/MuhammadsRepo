package com.edge.light.live.wallpaper;

import android.app.ProgressDialog;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
//import android.support.p003v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.dingmouren.videowallpaper.VideoWallpaper;
import com.edge.light.live.wallpaper.adapter.ImageListAdapter;
import com.edge.light.live.wallpaper.cropper.CropImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class ListActivity extends AppCompatActivity {
    ImageListAdapter adapter;
    ImageView back;
    int f57h;
    ListView list;
    VideoWallpaper mVideoWallpaper;
    ProgressDialog progress;
    ImageView sc2_text;
    String[] thumb;
    TextView title;
    Typeface typeface;
    String[] videos;
    View view_above;
    View view_below;
    int f58w;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_list);

        this.f58w = getResources().getDisplayMetrics().widthPixels;
        this.f57h = getResources().getDisplayMetrics().heightPixels;
        this.progress = new ProgressDialog(this);
        this.progress.setMessage("Loading...");
        this.progress.setCancelable(false);
        this.mVideoWallpaper = new VideoWallpaper();
        this.back = (ImageView) findViewById(R.id.back);
        this.sc2_text = (ImageView) findViewById(R.id.sc2_text);
        this.view_below = findViewById(R.id.view_below);
        this.view_above = findViewById(R.id.view_above);
        this.list = (ListView) findViewById(R.id.list);
        this.title = (TextView) findViewById(R.id.title);
        this.typeface = Typeface.createFromAsset(getAssets(), "Franklin Gothic Book Regular.ttf");
        this.title.setTypeface(this.typeface);
        try {
            this.thumb = getAssets().list("thumb");
            this.videos = getAssets().list("videos");
        } catch (Exception e) {
//            e.toString();
            Toast.makeText(mVideoWallpaper, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        this.adapter = new ImageListAdapter(this, this.thumb);
        this.list.setAdapter(this.adapter);
        this.list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                new CopyFile(position).execute(new String[0]);
            }
        });
        this.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ListActivity.this.onBackPressed();
            }
        });
        setLayout();
    }


    public void setLayout() {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.f58w * 60) / 1080, (this.f58w * 60) / 1080);
        params.addRule(13);
        this.back.setLayoutParams(params);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.f58w * 633) / 1080, (this.f58w * 165) / 1080);
        int m = (this.f58w * CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE) / 1080;
        params1.setMargins(0, m, 0, m);
        params1.addRule(14);
        this.sc2_text.setLayoutParams(params1);
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams(-1, (this.f58w * 360) / 1080);
        params2.addRule(12);
        this.view_below.setLayoutParams(params2);
        this.view_above.setLayoutParams(new RelativeLayout.LayoutParams(-1, (this.f58w * 360) / 1080));
    }


    public void writeMp4ToNative(File file, InputStream is) {
        try {
            FileOutputStream os = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            while (is.read(buffer) != -1) {
                os.write(buffer, 0, buffer.length);
            }
            os.flush();
            os.close();
            is.close();
            this.mVideoWallpaper.setToWallPaper(this, file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
//            Toast.makeText(this, "Something went Wrong...", 0).show();
        }
    }

    class CopyFile extends AsyncTask<String, String, String> {
        int position;

        CopyFile(int pos) {
            this.position = pos;
        }


        public void onPreExecute() {
            try {
                ListActivity.this.progress.show();
            } catch (Exception e) {
                e.toString();
            }
            super.onPreExecute();
        }


        public void onPostExecute(String result) {
            try {
                ListActivity.this.progress.dismiss();
            } catch (Exception e) {
                e.toString();
            }
            super.onPostExecute(result);
        }


        public String doInBackground(String... params) {
            File mFile2 = new File(Environment.getExternalStorageDirectory() + "/" + ListActivity.this.getResources().getString(R.string.app_name));
            mFile2.mkdirs();
            File mFile22 = new File(mFile2.getAbsoluteFile() + "/wallvideo.mp4");
//            try {
            try {
                mFile22.createNewFile();
            }
            catch (IOException e) {
                Log.e("====error",e.getMessage());
                e.printStackTrace();
            }
            try {
                ListActivity.this.writeMp4ToNative(mFile22, ListActivity.this.getAssets().open("videos/" + ListActivity.this.videos[this.position]));
            }
            catch (IOException e) {
                Log.e("====errora",e.getMessage());
                e.printStackTrace();
            }
            return null;
//            } catch (IOException e) {
//                e.printStackTrace();
//                return null;
//            }
        }
    }
}
