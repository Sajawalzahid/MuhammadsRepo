package com.edge.light.live.wallpaper;

import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.p003v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.edge.light.live.wallpaper.cropper.CropImageView;

public class CropActivity extends AppCompatActivity {
    ImageView back;
    CropImageView cropimageview;
    ImageView done;


    int f51h;

    /* renamed from: hi */
    int f52hi;
    TextView title;
    Typeface typeface;


    int f53w;

    /* renamed from: wi */
    int f54wi;


    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_crop);

        this.f53w = getResources().getDisplayMetrics().widthPixels;
        this.f51h = getResources().getDisplayMetrics().heightPixels;
        this.done = (ImageView) findViewById(R.id.done);
        this.back = (ImageView) findViewById(R.id.back);
        this.cropimageview = (CropImageView) findViewById(R.id.cropimageview);
        this.title = (TextView) findViewById(R.id.title);
        this.typeface = Typeface.createFromAsset(getAssets(), "Franklin Gothic Book Regular.ttf");
        this.title.setTypeface(this.typeface);
        this.cropimageview.setImageUriAsync(Utils.uri);
        this.cropimageview.setFixedAspectRatio(true);
        this.done.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Utils.bitmap = CropActivity.this.bitmapResize(CropActivity.this.cropimageview.getCroppedImage());
                CropActivity.this.setResult(-1);
                CropActivity.this.finish();
            }
        });
        this.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CropActivity.this.onBackPressed();
            }
        });
        FindRatio();
        setLayout();
    }


    public void setLayout() {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.f53w * 60) / 1080, (this.f53w * 60) / 1080);
        params.addRule(13);
        this.back.setLayoutParams(params);
        this.done.setLayoutParams(params);
    }

    public void FindRatio() {
        this.f54wi = this.f53w;
        this.f52hi = this.f51h;
        if (!("" + this.f52hi).endsWith("0")) {
            this.f52hi += 96;
        }
        ratio(this.f54wi, this.f52hi);
    }


    public int gcd(int p, int q) {
        return q == 0 ? p : gcd(q, p % q);
    }


    public void ratio(int a, int b) {
        Log.e("HW", a + ":" + b);
        int gcd = gcd(a, b);
        if (a > b) {
            showAnswer(a / gcd, b / gcd);
        } else {
            showAnswer(b / gcd, a / gcd);
        }
    }


    public void showAnswer(int a, int b) {
        Log.e("Ratio", a + ":" + b);
        this.cropimageview.setAspectRatio(b, a);
    }

    public Bitmap bitmapResize(Bitmap bit) {
        int newheight;
        int newwidth;
        int layoutwidth = this.f54wi;
        int layoutheight = this.f52hi;
        int imagewidth = bit.getWidth();
        int imageheight = bit.getHeight();
        if (imagewidth >= imageheight) {
            newwidth = layoutwidth;
            newheight = (newwidth * imageheight) / imagewidth;
            if (newheight > layoutheight) {
                newwidth = (layoutheight * newwidth) / newheight;
                newheight = layoutheight;
            }
        } else {
            newheight = layoutheight;
            newwidth = (newheight * imagewidth) / imageheight;
            if (newwidth > layoutwidth) {
                newheight = (newheight * layoutwidth) / newwidth;
                newwidth = layoutwidth;
            }
        }
        return Bitmap.createScaledBitmap(bit, newwidth, newheight, true);
    }
}
