package com.edge.light.live.wallpaper;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.MediaStore;
//import android.support.annotation.Nullable;
//import android.support.p003v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.dingmouren.videowallpaper.BuildConfig;
import com.edge.light.live.wallpaper.Tools.AppAdOrganizer;
import com.edge.light.live.wallpaper.service.MYHelper;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.NativeAdLayout;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.edge.light.live.wallpaper.Tools.AppTimeHandler.appStructureBase;

public class SetBackgroundActivity extends AppCompatActivity {
    int CROP_IMG = 222;
    int SEL_FIRST = 111;
    ImageView add;
    ImageView back;


    int f68h;
    CircleImageView img;
    ImageView img_enable;
    LinearLayout lay1;
    LinearLayout lay2;
    SharedPreferences pref;
    TextView title;
    Typeface typeface;


    int f69w;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_set_background);
        NativeAdLayout fbnativeAdLayout = findViewById(R.id.fbnative_banner_ad_container);
        FrameLayout adrelative = findViewById(R.id.adrelative);
        FrameLayout adViewAdaptiveBanner = findViewById(R.id.adViewAdaptiveBanner);

        if (appStructureBase.getFb_banner_option2() == 1) {
            fbnativeAdLayout.setVisibility(View.VISIBLE);
            adrelative.setVisibility(View.VISIBLE);
            AdView adView = new AdView(this, appStructureBase.getFb_banner_id(), AdSize.BANNER_HEIGHT_50);
            fbnativeAdLayout.addView(adView);
            adView.loadAd();

        } else if(appStructureBase.getGoogle_banner_option2() == 1) {
            AppAdOrganizer.getInstance().loadAdMobBannerAd(SetBackgroundActivity.this, adViewAdaptiveBanner, AppAdOrganizer.getInstance().getAdSize(Objects.requireNonNull(SetBackgroundActivity.this), adViewAdaptiveBanner));
            adViewAdaptiveBanner.setVisibility(View.VISIBLE);
            adrelative.setVisibility(View.VISIBLE);
        }else {
            adViewAdaptiveBanner.setVisibility(View.GONE);
            fbnativeAdLayout.setVisibility(View.GONE);
            adrelative.setVisibility(View.GONE);
        }
        this.pref = getSharedPreferences(MYHelper.share_pref_key, 0);
        this.f69w = getResources().getDisplayMetrics().widthPixels;
        this.f68h = getResources().getDisplayMetrics().heightPixels;
        this.title = (TextView) findViewById(R.id.title);
        this.lay1 = (LinearLayout) findViewById(R.id.lay1);
        this.lay2 = (LinearLayout) findViewById(R.id.lay2);
        this.add = (ImageView) findViewById(R.id.add);
        this.back = (ImageView) findViewById(R.id.back);
        this.img_enable = (ImageView) findViewById(R.id.img_enable);
        this.img = (CircleImageView) findViewById(R.id.img);
        this.typeface = Typeface.createFromAsset(getAssets(), "Franklin Gothic Book Regular.ttf");
        this.title.setTypeface(this.typeface);
        this.lay1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (SetBackgroundActivity.this.pref.getBoolean("enableimage", false)) {
                    SetBackgroundActivity.this.pref.edit().putBoolean("enableimage", false).apply();
                } else {
                    SetBackgroundActivity.this.pref.edit().putBoolean("enableimage", true).apply();
                }
                SetBackgroundActivity.this.check();
            }
        });
        this.add.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SetBackgroundActivity.this.select_Image(SetBackgroundActivity.this.SEL_FIRST);
            }
        });
        this.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SetBackgroundActivity.this.onBackPressed();
            }
        });
        check();
        setLayout();
    }


    public void setLayout() {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.f69w * 60) / 1080, (this.f69w * 60) / 1080);
        params.addRule(13);
        this.back.setLayoutParams(params);
        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((this.f69w * 93) / 1080, (this.f69w * 93) / 1080);
        params1.addRule(13);
        this.add.setLayoutParams(params1);
        RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams((this.f69w * 118) / 1080, (this.f69w * 118) / 1080);
        params2.addRule(13);
        this.img.setLayoutParams(params2);
        LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams((this.f69w * 772) / 1080, (this.f69w * 166) / 1080);
        params3.setMargins(0, (this.f69w * 100) / 1080, 0, 0);
        this.lay1.setLayoutParams(params3);
        this.lay2.setLayoutParams(params3);
        RelativeLayout.LayoutParams params4 = new RelativeLayout.LayoutParams((this.f69w * 80) / 1080, (this.f69w * 39) / 1080);
        params4.addRule(13);
        this.img_enable.setLayoutParams(params4);
    }


    public void check() {
        if (this.pref.getBoolean("enableimage", false)) {
            this.img_enable.setImageResource(R.drawable.toggle_on);
            this.lay1.setBackgroundResource(R.drawable.bg_enable);
        } else {
            this.img_enable.setImageResource(R.drawable.toggle_off);
            this.lay1.setBackgroundResource(R.drawable.bg_disable);
        }
        Bitmap bit = getImage();
        if (bit != null) {
            this.img.setImageBitmap(bit);
        }
    }


    public void select_Image(int code) {
        startActivityForResult(new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI), code);
    }


    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == this.SEL_FIRST && resultCode == -1 && data != null) {
            Utils.uri = data.getData();
            startActivityForResult(new Intent(getApplicationContext(), CropActivity.class), this.CROP_IMG);
        }
        if (requestCode == this.CROP_IMG && resultCode == -1) {
            generateBitmap(Utils.bitmap, this);
            this.pref.edit().putBoolean(BuildConfig.APPLICATION_ID, true).apply();
        }
    }


    public void generateBitmap(Bitmap bitmap, Context context) {
        try {
            OutputStream fileOutputStream = new FileOutputStream(new File(String.valueOf(context.getFilesDir()) + File.separator + "bg.png"));
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Compress start: ");
            stringBuilder2.append(System.nanoTime());
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            context.getSharedPreferences(BuildConfig.APPLICATION_ID, 0).edit().putBoolean("newimage", true).apply();
            fileOutputStream.close();
        } catch (Exception e) {
            e.toString();
        }
        check();
    }

    public Bitmap getImage() {
        Context applicationContext = getApplicationContext();
        if (!new File(applicationContext.getFilesDir() + File.separator + "bg.png").exists()) {
            return null;
        }
        return BitmapFactory.decodeFile(String.valueOf(applicationContext.getFilesDir()) + File.separator + "bg.png");
    }
}
