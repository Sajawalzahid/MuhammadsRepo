package com.edge.light.live.wallpaper;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
//import android.support.p003v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.edge.light.live.wallpaper.Tools.AppAdOrganizer;
import com.edge.light.live.wallpaper.datamodel.AppStructureBase;
import com.facebook.ads.AudienceNetworkAds;
import static com.edge.light.live.wallpaper.Tools.AppTimeHandler.appStructureBase;

public class SplashActivity extends AppCompatActivity {


    int f72h;
    ImageView splash_text;


    int f73w;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_splash);

        appStructureBase = new AppStructureBase();
        AppAdOrganizer.getInstance().initAdMobAd(this);
        AudienceNetworkAds.initialize(this);
        this.f73w = getResources().getDisplayMetrics().widthPixels;
        this.f72h = getResources().getDisplayMetrics().heightPixels;
        this.splash_text = (ImageView) findViewById(R.id.splash_text);
//        new Handler().postDelayed(new Runnable() {
//            public void run() {
            appStructureBase.setInter_id("ca-app-pub-3940256099942544/1033173712");
            appStructureBase.setNative_id("ca-app-pub-3940256099942544/2247696110");
            appStructureBase.setBanner_id("ca-app-pub-3940256099942544/630097811");
                appStructureBase.setFb_inter_id("YOUR_PLACEMENT_ID");
                appStructureBase.setFb_native_id("YOUR_PLACEMENT_ID");
                appStructureBase.setFb_banner_id("YOUR_PLACEMENT_ID");
                appStructureBase.setFb_banner_home(0);
                appStructureBase.setGoogle_banner_home(0);
                appStructureBase.setFb_native_option1(0);
                appStructureBase.setGoogle_native_option1(0);
                appStructureBase.setFb_banner_option2(0);
                appStructureBase.setGoogle_banner_option2(0);
                appStructureBase.setFb_inter_home(0);
                appStructureBase.setGoogle_inter_home(0);
                appStructureBase.setFb_inter_option1(0);
                appStructureBase.setGoogle_inter_option1(0);



//            }
//        }, 3000);
        setLayout();
        SplashActivity.this.startActivity(new Intent(SplashActivity.this.getApplicationContext(), MainActivity.class));
        SplashActivity.this.finish();
    }


    public void setLayout() {
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((this.f73w * 620) / 1080, (this.f73w * 281) / 1080);
        params.addRule(13);
        this.splash_text.setLayoutParams(params);
    }
}
