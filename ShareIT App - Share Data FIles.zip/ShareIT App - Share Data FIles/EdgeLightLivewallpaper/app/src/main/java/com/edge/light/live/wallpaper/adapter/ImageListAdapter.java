package com.edge.light.live.wallpaper.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.edge.light.live.wallpaper.R;

public class ImageListAdapter extends BaseAdapter {
    String[] dms;
    Context mContext;
    Typeface typeface;

    public ImageListAdapter(Context context, String[] dms2) {
        this.mContext = context;
        this.dms = dms2;
    }

    public int getCount() {
        return this.dms.length;
    }

    public Object getItem(int arg0) {
        return Integer.valueOf(arg0);
    }

    public long getItemId(int arg0) {
        return (long) arg0;
    }

    public View getView(int position, View view, ViewGroup arg2) {
        typeface=Typeface.createFromAsset(this.mContext.getAssets(), "Franklin Gothic Book Regular.ttf");
        Context context = this.mContext;
        Context context2 = this.mContext;
        View view2 = ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(R.layout.image_list_adapter, (ViewGroup) null);
        LinearLayout mainlay = (LinearLayout) view2.findViewById(R.id.mainlay);
        int w = this.mContext.getResources().getDisplayMetrics().widthPixels;
//        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams((w * 805) / 1080, (w * 152) / 1080);
//        params.addRule(14);
//        int m = (w * 30) / 1080;
//        if (this.dms.length - 1 == position) {
//            params.setMargins(0, m, 0, m);
//        } else {
//            params.setMargins(0, m, 0, 0);
//        }
//        mainlay.setLayoutParams(params);
        ImageView img = (ImageView) view2.findViewById(R.id.img);
        Glide.with(this.mContext).load("file:///android_asset/thumb/" + this.dms[position]).into(img);
//        RelativeLayout.LayoutParams params1 = new RelativeLayout.LayoutParams((w * 130) / 1080, (w * 130) / 1080);
//        params1.addRule(13);
//        img.setLayoutParams(params1);
//        ((TextView) view2.findViewById(R.id.txt)).setTypeface(this.typeface);
        return view2;
    }
}
